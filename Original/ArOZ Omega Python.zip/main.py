import pygame, sys
from pygame.locals import *

#/////////////////////////////////////////////////////////////////
#define system variables
#/////////////////////////////////////////////////////////////////
ScreenWidth = 1024 #The Screen Width in pixels
ScreenHeight = 600 #The Screen Height in pixels
spritefolder = "ghost/" #The directory to store all the surface
goffsets = [50,30] #Offsets of ghost to the boundary of form
ghostlocation = (0,0)#define ghost location
global eyelayer, cl1, expressiontick
eyelayer = None #Top layer
cl1 = None#Layer 1
expressiontick = 0#Time counter for expression changes

#/////////////////////////////////////////////////////////////////
#System Initiation
#/////////////////////////////////////////////////////////////////
pygame.init()
form = pygame.display.set_mode((ScreenWidth, ScreenHeight))
#form = pygame.display.set_mode((ScreenWidth, ScreenHeight),pygame.NOFRAME)
pygame.display.set_caption('ArOZ Omega Raspberry pi Edition')
basicFont = pygame.font.SysFont(None, 48)
EYECONTROL, t = pygame.USEREVENT+1, 100
pygame.time.set_timer(EYECONTROL, t)
ghostimg = pygame.image.load(spritefolder + 'surface0.png').convert_alpha()

#/////////////////////////////////////////////////////////////////
#Convenience Functions for file and image handling
#/////////////////////////////////////////////////////////////////
def LoadImage(filename,size=[0,0]):
    #Load the image using filename (with resize)
    img = pygame.image.load(spritefolder + filename + '.png').convert_alpha()
    defaultsize = img.get_rect().size
    if size==[0,0]:
        return img
    else:
        img = pygame.transform.scale(img,(size[0],size[1]))
        return img
    
def DrawImage(image,location):
    #Draw the image to screen with certain location.
    form.blit(image,location)
    #pygame.display.update()

def GetImageSize(image):
    #Get the image size in array[x,y]
    return image.get_rect().size

def Merge(image1,image2):
    image1.blit(image2,(0,0))
    return image1
#/////////////////////////////////////////////////////////////////
#Motion Controlling Functions
#/////////////////////////////////////////////////////////////////
global eyestate,expressionmode
eyestate = 0#eyestate use as a timer for eye status calculation
expressionmode = False
def Eye_blink():
    global eyestate
    if expressionmode == False:
        eyestate += 1
        if eyestate == 1:
            print("Looped Eyestate")
            return None
        elif eyestate == 53:
            print("Eye Semiclosed")
            eyeimg = LoadImage("surface100")
            return eyeimg
        elif eyestate == 54:
            print("Eye closed")
            eyeimg = LoadImage("surface101")
            return eyeimg
        elif eyestate == 55:
            print("Eye Semiclosed")
            eyeimg = LoadImage("surface100")
            eyestate = 0
            return eyeimg
    else:
        return None
def ClickHandler(coordinates,ghostlocation,ghostsize):
    global expressionmode
    clickx = coordinates[0]
    clicky = coordinates[1]
    glx = ghostlocation[0]
    gly = ghostlocation[1]
    gsx = ghostsize[0]
    gsy = ghostsize[1]
    if clickx > glx and clickx < (glx + gsx):
        if clicky > gly and clicky < (gly + gsy):
            expressionmode = True
            print("Click in range")
            return LoadImage("surface2")
        else:
            print("Click out of range")
            return False

def InterfaceReset(expressiontick):
    global expressionmode
    if expressiontick > 30:
        expressionmode = False
    return False
#/////////////////////////////////////////////////////////////////
#Main Loop
#/////////////////////////////////////////////////////////////////
def main():
    # set up the colors
    BLACK = (0, 0, 0)
    WHITE = (255, 255, 255)
    RED = (255, 0, 0)
    GREEN = (0, 255, 0)
    BLUE = (0, 0, 255)

    # set up the text
    text = basicFont.render('Hello world!', True, WHITE)
    textRect = text.get_rect()
    textRect.centerx = form.get_rect().centerx
    textRect.centery = form.get_rect().centery

    # draw the white background onto the surface
    form.fill(BLACK)
    # draw the text's background rectangle onto the surface
    pygame.draw.rect(form, BLACK, (textRect.left - 20, textRect.top - 20, textRect.width + 40, textRect.height + 40))


    # draw the text onto the surface
    form.blit(text, textRect)
    ghostimg = LoadImage("surface0")
    ims = GetImageSize(ghostimg)
    ghostlocation = (ScreenWidth - ims[0] + goffsets[0],ScreenHeight - ims[1]+goffsets[1])
    #MAIN LOGIC LOOP
    while True:
        global eyelayer,cl1,cl2,expressiontick,expressionmode
        for event in pygame.event.get():
            #Initializing all layers
            #There are four layers
            # TOP: Eye Layer
            # 2nd: Clothes Layer 1
            # 3rd: Clothes Layer 2
            # 4th: Body Layer (Standard)
            #Define layers
            form.fill(BLACK)
            cl2 = LoadImage("surface1353")
            bl = LoadImage("surface0")

            if event.type == QUIT: #Closing Handler
                print("[Info]System Exiting...")
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:#Mouse Click Handler
                pos = pygame.mouse.get_pos()
                print(pos[0],pos[1])
                returnvalue = ClickHandler(pos,ghostlocation,GetImageSize(bl))
                if returnvalue != False:
                    eyelayer = returnvalue
            if event.type == pygame.KEYDOWN:#Keypress Handler
                if event.key == pygame.K_ESCAPE:
                    print("[Info]System Exiting...")
                    pygame.quit()
                    sys.exit()
                if event.key == pygame.K_0:
                    form.fill(BLACK)#Refresh Screen if stuck
            if event.type == EYECONTROL: #Eye Blink Controller, also act as timer
                if expressionmode == False:
                    eyelayer = Eye_blink()
                    expressiontick = 0
                else:
                    expressiontick += 1
                    InterfaceReset(expressiontick)
                
        #Compare layers and draw them to the form
        if cl2 != None:
            bl.blit(cl2,(0,0))
        if cl1 != None:
            bl.blit(cl1,(0,0))
        if eyelayer != None:
            bl.blit(eyelayer,(0,0))
        form.blit(bl,ghostlocation)
        pygame.display.flip()
#/////////////////////////////////////////////////////////////////
#Initiation of Main
#/////////////////////////////////////////////////////////////////
main()
